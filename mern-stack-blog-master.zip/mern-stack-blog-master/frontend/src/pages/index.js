import Login from "./login/login";
import Register from "./register/register";
import Posts from "./posts/posts";

export { Login, Register, Posts };